# README

## Compilation
```
Compilation:
    pdflatex main.tex
    bibtex main
    pdflatex main.tex
    pdflatex main.tex

Contents:
    main.tex
    refs.bib
    figures/
        xor_vs_tseitin_plot.pdf
        histograms_combo.pdf
    data/
        *.csv
```

## Contents
- `main.tex`
- `refs.bib`
- `figures/`
- `data/`

## Data Files Included
- php_7_6_summary.csv
- tseitin_odd_summary.csv
- xor_contradiction_summary.csv
- modular_test_results_final.csv
