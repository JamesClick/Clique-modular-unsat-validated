import pandas as pd
import matplotlib.pyplot as plt

# Read validated results
df = pd.read_csv("data/verified_results.csv")

# Scatter: vertices vs clique size
plt.figure(figsize=(8,6))
colors = df["is_modular"].map({True:"blue", False:"orange"})
plt.scatter(df["n_vertices"], df["k_clique"], c=colors, alpha=0.7, s=80)
plt.xlabel("Number of vertices (n)")
plt.ylabel("Clique size (k)")
plt.title("Vertices vs Clique Size")
plt.grid(True)
plt.savefig("figures/vertices_clique_scatter.png", dpi=300)

# Bar: average time by result
if "time_to_unsat" in df.columns:
    avg = df.groupby("expected_result")["time_to_unsat"].mean()
    avg.plot(kind="bar", title="Average Time to UNSAT/SAT")
    plt.ylabel("Mean time (s)")
    plt.tight_layout()
    plt.savefig("figures/avg_time_bar.png", dpi=300)
