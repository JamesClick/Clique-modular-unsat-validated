import csv
import os
import subprocess

# Configurações
INPUT_CSV = "data/modular_test_results.csv"
OUTPUT_CSV = "data/verified_results.csv"
PROOFS_DIR = "proofs/"
SOLVER = "glucose"

def is_valid_row(n_vertices, k_clique):
    return 1 <= k_clique <= n_vertices

def verify_proof(cnf_file, proof_file):
    if not os.path.exists(cnf_file) or not os.path.exists(proof_file):
        return False
    try:
        result = subprocess.run(["drat-trim", cnf_file, proof_file],
                                capture_output=True, text=True)
        return "VERIFIED" in result.stdout
    except Exception:
        return False

def fix_csv():
    with open(INPUT_CSV, 'r') as f_in, open(OUTPUT_CSV, 'w', newline='') as f_out:
        reader = csv.DictReader(f_in)
        fieldnames = reader.fieldnames + ["is_valid", "notes"]
        writer = csv.DictWriter(f_out, fieldnames=fieldnames)
        writer.writeheader()
        for row in reader:
            n_vertices = int(row["n_vertices"])
            k_clique = int(row["k_clique"])
            notes = ""
            valid = is_valid_row(n_vertices, k_clique)
            if not valid:
                notes = f"k_clique>n_vertices (k={k_clique},n={n_vertices})"
            if valid and row.get("expected_result","") == "UNSAT":
                cnf_file = os.path.join(PROOFS_DIR, f"unsat_k{k_clique}_n{n_vertices}.cnf")
                proof_file = os.path.join(PROOFS_DIR, f"unsat_k{k_clique}_n{n_vertices}.drat")
                if not verify_proof(cnf_file, proof_file):
                    notes = "Proof not verified"
                    valid = False
            row["is_valid"] = valid
            row["notes"] = notes
            writer.writerow(row)
    print(f"Validated CSV saved to {OUTPUT_CSV}")

if __name__ == "__main__":
    fix_csv()
